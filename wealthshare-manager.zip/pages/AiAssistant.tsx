
import React, { useState, useRef, useEffect } from 'react';
import { useStore } from '../store';
import { askFinancialAssistant } from '../utils/aiHelper';
import { ActionDraft } from '../types';
import { 
  Send, 
  Sparkles, 
  Bot, 
  User, 
  CheckCircle, 
  Loader2,
  List,
  Plus,
  ArrowRight,
  Trash2
} from 'lucide-react';
import { AccountType } from '../types';

export const AiAssistant: React.FC = () => {
  const { 
    members, accounts, loans, transactions, workingDate, chatMessages,
    addContribution, addRepayment, addExpense, getLoanDetails,
    addMember, addAccount, addLoan, addTransfer,
    addChatMessage, clearChatHistory
  } = useStore();
  
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages, isLoading]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;

    await addChatMessage('user', input);
    const userInput = input; // Capture for use in async call
    setInput('');
    setIsLoading(true);

    try {
      const response = await askFinancialAssistant(userInput, { 
        members, accounts, loans, transactions, workingDate, chatHistory: chatMessages 
      });
      
      const responseText = response.type === 'ANSWER' ? response.text : `I've prepared ${response.actions?.length || 0} actions. Please confirm:`;
      await addChatMessage('ai', responseText, response.type === 'DRAFT_ACTIONS' ? response.actions : undefined);

    } catch (err) {
      await addChatMessage('ai', "Sorry, I encountered an error processing that request.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleConfirmActions = async (actions: ActionDraft[]) => {
    setIsLoading(true);
    let successCount = 0;
    let errors: string[] = [];
    
    // We maintain a map of newly created names to IDs to support limited chaining within the same batch (best effort)
    const newMemberMap = new Map<string, string>();
    const newAccountMap = new Map<string, string>();

    // Process actions sequentially to allow dependencies (e.g., create member -> add contribution)
    for (const act of actions) {
      let result: string | null = null;
      const notes = act.notes || 'AI Action';
      const dateToUse = act.date || workingDate;

      // Resolve IDs from Maps if missing (for chained creation)
      let resolvedMemberId = act.memberId;
      if (!resolvedMemberId && act.memberName && newMemberMap.has(act.memberName)) {
        resolvedMemberId = newMemberMap.get(act.memberName);
      }

      try {
        switch (act.type) {
          case 'ADD_MEMBER':
            if (act.memberName) {
              const newId = await addMember(act.memberName, act.startingCredit || 0);
              newMemberMap.set(act.memberName, newId);
            } else errors.push('Missing name for ADD_MEMBER');
            break;

          case 'ADD_ACCOUNT':
            if (act.accountName && act.accountType) {
              const newId = await addAccount(act.accountName, act.accountType as AccountType, resolvedMemberId);
              newAccountMap.set(act.accountName, newId);
            } else errors.push('Missing details for ADD_ACCOUNT');
            break;

          case 'CREATE_LOAN':
            if (resolvedMemberId && act.accountId && act.amount) {
              result = await addLoan(resolvedMemberId, act.amount, act.accountId, dateToUse, act.interestRate || 10);
            } else errors.push('Missing details for CREATE_LOAN');
            break;

          case 'TRANSFER':
            if (act.accountId && act.toAccountId && act.amount) {
              await addTransfer(act.accountId, act.toAccountId, act.amount, act.fundType || 'PRINCIPAL', dateToUse, notes);
            } else errors.push('Missing details for TRANSFER');
            break;

          case 'CONTRIBUTION':
            if (resolvedMemberId && act.accountId && act.amount) {
              result = await addContribution(resolvedMemberId, act.amount, act.accountId, dateToUse, notes);
            } else errors.push(`Missing details for CONTRIBUTION (${act.memberName || 'Unknown'})`);
            break;

          case 'LOAN_REPAYMENT':
            if (resolvedMemberId && act.accountId && act.amount) {
               // Find active unpaid loan for this member
               const memberLoans = loans.filter(l => l.memberId === resolvedMemberId);
               const unpaidLoan = memberLoans.find(l => getLoanDetails(l).status !== 'PAID');
               if (unpaidLoan) {
                 await addRepayment(unpaidLoan.id, act.amount, act.accountId, dateToUse, notes);
               } else {
                 result = `No unpaid loan for ${act.memberName || 'member'}`;
               }
            } else errors.push('Missing details for LOAN_REPAYMENT');
            break;

          case 'EXPENSE':
            if (act.accountId && act.amount) {
              result = await addExpense(act.amount, act.accountId, dateToUse, notes);
            } else errors.push('Missing details for EXPENSE');
            break;

           case 'OPENING_BALANCE':
              // Not yet fully exposed to AI, but safety catch
              break;
        }
      } catch (e: any) {
        result = e.message || 'Unknown error';
      }

      if (result) {
        errors.push(result);
      } else if (!errors.includes('Missing')) {
        successCount++;
      }
    }

    setIsLoading(false);

    let summaryText = '';
    if (errors.length > 0 && successCount === 0) {
      summaryText = `Failed to execute actions:\n${errors.join('\n')}`;
    } else if (errors.length > 0) {
      summaryText = `Executed ${successCount} actions, but some failed:\n${errors.slice(0, 3).join('\n')}...`;
    } else {
      summaryText = `✅ Successfully executed ${successCount} actions.`;
    }

    await addChatMessage('ai', summaryText);
  };

  const getActionIcon = (type: string) => {
    switch(type) {
      case 'ADD_MEMBER': return <User size={14} className="text-blue-600" />;
      case 'ADD_ACCOUNT': return <List size={14} className="text-purple-600" />;
      case 'CREATE_LOAN': return <Plus size={14} className="text-rose-600" />;
      case 'TRANSFER': return <ArrowRight size={14} className="text-slate-600" />;
      default: return <CheckCircle size={14} className="text-emerald-600" />;
    }
  };

  return (
    <div className="h-[calc(100vh-100px)] flex flex-col max-w-4xl mx-auto">
      <div className="flex-none mb-4 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Sparkles className="text-purple-600" /> Admin AI Assistant
          </h1>
          <p className="text-slate-500">Full control to create members, accounts, loans, and records.</p>
        </div>
        {chatMessages.length > 0 && (
          <button 
            onClick={() => {
              if (window.confirm("Clear chat history?")) clearChatHistory();
            }}
            className="text-slate-400 hover:text-red-600 p-2"
            title="Clear History"
          >
            <Trash2 size={20} />
          </button>
        )}
      </div>

      <div className="flex-1 bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex flex-col">
        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50">
          {chatMessages.length === 0 && (
            <div className="flex justify-start">
              <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-none p-4 shadow-sm text-slate-800">
                <div className="flex items-center gap-2 mb-1 opacity-70 text-xs">
                  <Bot size={12} />
                  <span>Admin AI</span>
                </div>
                <p className="whitespace-pre-wrap">
                  Hello! I'm your WealthShare Admin AI. I can manage members, accounts, loans, and transactions.<br/><br/>
                  Try:<br/>
                  • 'Add a new member named John'<br/>
                  • 'Give P1 a loan of 5000 MK'<br/>
                  • 'Transfer 2000 from Cash to Bank'<br/>
                  • 'Everyone paid 1000 today'
                </p>
              </div>
            </div>
          )}

          {chatMessages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`
                max-w-[90%] md:max-w-[80%] rounded-2xl p-4 shadow-sm
                ${msg.sender === 'user' 
                  ? 'bg-blue-600 text-white rounded-tr-none' 
                  : 'bg-white border border-slate-200 text-slate-800 rounded-tl-none'}
              `}>
                <div className="flex items-center gap-2 mb-1 opacity-70 text-xs">
                  {msg.sender === 'user' ? <User size={12} /> : <Bot size={12} />}
                  <span>{msg.sender === 'user' ? 'You' : 'Admin AI'}</span>
                </div>
                
                {msg.text && <p className="whitespace-pre-wrap">{msg.text}</p>}

                {/* Action Card List */}
                {msg.actions && msg.actions.length > 0 && (
                  <div className="mt-3 bg-slate-50 border border-slate-200 rounded-lg p-3 text-sm text-slate-700">
                    <h4 className="font-bold text-slate-900 mb-2 flex items-center gap-2">
                      <List size={14} /> 
                      {msg.actions.length} Proposed Actions
                    </h4>
                    
                    <div className="max-h-40 overflow-y-auto space-y-2 mb-3 pr-2">
                      {msg.actions.map((act, idx) => (
                        <div key={idx} className="bg-white p-2 rounded border border-slate-100 text-xs flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            {getActionIcon(act.type)}
                            <div>
                              <span className="font-bold text-slate-700 block">
                                {act.type.replace('_', ' ')}
                              </span>
                              <span className="text-slate-500">
                                {act.memberName || act.accountName || 'System'} • {act.date || 'Today'}
                              </span>
                            </div>
                          </div>
                          {act.amount && (
                            <span className="font-bold text-slate-700 bg-slate-100 px-2 py-1 rounded">
                              {act.amount.toLocaleString()} MK
                            </span>
                          )}
                        </div>
                      ))}
                    </div>

                    <div className="flex justify-between items-center pt-2 border-t border-slate-200">
                      <div className="text-xs text-slate-500 font-medium">
                        Click confirm to execute
                      </div>
                      <button 
                        onClick={() => handleConfirmActions(msg.actions!)}
                        disabled={isLoading}
                        className="bg-emerald-600 text-white py-1.5 px-4 rounded hover:bg-emerald-700 flex items-center justify-center gap-1 font-medium text-sm transition-colors disabled:opacity-50"
                      >
                         {isLoading ? <Loader2 className="animate-spin" size={14} /> : <CheckCircle size={14} />} 
                         Confirm All
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-none p-4 shadow-sm flex items-center gap-2 text-slate-500">
                <Loader2 size={16} className="animate-spin" />
                Processing...
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-white border-t border-slate-100">
          <form onSubmit={handleSend} className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Command me... e.g. 'Add member Sarah'"
              className="flex-1 px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white text-slate-900"
              autoFocus
            />
            <button 
              type="submit" 
              disabled={isLoading || !input.trim()}
              className="bg-purple-600 text-white p-2 rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Send size={20} />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
