
import React, { useState, useEffect } from 'react';
import { useStore } from '../store';
import { 
  Plus, 
  Calendar, 
  AlertCircle,
  CheckCircle2,
  Clock,
  History,
  Loader2
} from 'lucide-react';

export const Loans: React.FC = () => {
  const { 
    loans, 
    members, 
    accounts, 
    transactions,
    addLoan, 
    addRepayment, 
    getLoanDetails,
    workingDate,
    isLoading
  } = useStore();
  
  const [modalType, setModalType] = useState<'NEW_LOAN' | 'REPAY' | null>(null);
  const [selectedLoanId, setSelectedLoanId] = useState('');
  const [formData, setFormData] = useState({
    memberId: '',
    accountId: '',
    amount: '',
    interestRate: '10',
    date: workingDate,
    notes: ''
  });
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sync date with global working date when modal opens
  useEffect(() => {
    setFormData(prev => ({ ...prev, date: workingDate }));
  }, [workingDate, modalType]);

  const handleAction = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const amt = parseFloat(formData.amount);
    
    setIsSubmitting(true);
    
    if (modalType === 'NEW_LOAN') {
      const result = await addLoan(
        formData.memberId, 
        amt, 
        formData.accountId, 
        formData.date, 
        parseFloat(formData.interestRate)
      );
      if (result) setError(result);
      else closeModal();
    } else if (modalType === 'REPAY') {
      await addRepayment(selectedLoanId, amt, formData.accountId, formData.date, formData.notes);
      closeModal();
    }
    
    setIsSubmitting(false);
  };

  const closeModal = () => {
    setModalType(null);
    setSelectedLoanId('');
    setFormData({
      memberId: '',
      accountId: '',
      amount: '',
      interestRate: '10',
      date: workingDate,
      notes: ''
    });
  };

  if (isLoading) return <div className="p-8 text-center text-slate-500">Loading loans...</div>;

  const activeLoans = loans
    .filter(l => l.date_given <= workingDate) // Filter by workingDate
    .map(l => ({
      ...l,
      member: members.find(m => m.id === l.memberId),
      details: getLoanDetails(l), // getLoanDetails now respects workingDate
      repayments: transactions
        .filter(t => 
          t.related_loan_id === l.id && 
          t.transaction_type === 'LOAN_REPAYMENT' &&
          t.date <= workingDate // Filter repayments by workingDate
        )
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    })).sort((a, b) => new Date(b.date_given).getTime() - new Date(a.date_given).getTime());

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Loans</h1>
          <p className="text-slate-500">Manage member loans and repayment cycles</p>
        </div>
        <button 
          onClick={() => setModalType('NEW_LOAN')}
          className="flex items-center justify-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus size={20} />
          <span>New Loan</span>
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {activeLoans.map(loan => (
          <div key={loan.id} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
            <div className="flex flex-col md:flex-row md:items-center gap-6">
              <div className="flex-1 space-y-2">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold">
                    {loan.member?.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900">{loan.member?.name}</h3>
                    <div className="flex items-center text-xs text-slate-500 space-x-3">
                      <span className="flex items-center"><Calendar size={12} className="mr-1" /> {new Date(loan.date_given).toLocaleDateString()})</span>
                      <span className="flex items-center"><Clock size={12} className="mr-1" /> Due: {new Date(loan.due_date).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 flex-[2]">
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400 mb-1 tracking-wider">Total Due</p>
                  <p className="font-bold text-slate-900">{loan.details.totalDue.toLocaleString()} MK</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400 mb-1 tracking-wider">Paid</p>
                  <p className="font-bold text-emerald-600">{loan.details.amountPaid.toLocaleString()} MK</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400 mb-1 tracking-wider">Balance</p>
                  <p className={`font-bold ${loan.details.balance > 0 ? 'text-red-600' : 'text-slate-400'}`}>
                    {loan.details.balance.toLocaleString()} MK
                  </p>
                </div>
                <div className="flex items-center justify-end">
                  <span className={`px-2 py-1 rounded text-[10px] font-bold flex items-center ${
                    loan.details.status === 'PAID' ? 'bg-emerald-100 text-emerald-700' :
                    loan.details.status === 'OVERDUE' ? 'bg-red-100 text-red-700' :
                    'bg-blue-100 text-blue-700'
                  }`}>
                    {loan.details.status === 'PAID' ? <CheckCircle2 size={12} className="mr-1" /> :
                     loan.details.status === 'OVERDUE' ? <AlertCircle size={12} className="mr-1" /> :
                     <Clock size={12} className="mr-1" />}
                    {loan.details.status}
                  </span>
                </div>
              </div>

              {loan.details.status !== 'PAID' && (
                <button 
                  onClick={() => {
                    setSelectedLoanId(loan.id);
                    setModalType('REPAY');
                  }}
                  className="bg-slate-50 text-slate-700 hover:bg-slate-100 px-4 py-2 rounded-lg text-sm font-semibold transition-colors border"
                >
                  Repay
                </button>
              )}
            </div>

            {/* Repayment History Section */}
            {loan.repayments.length > 0 && (
              <div className="mt-6 pt-6 border-t border-slate-100">
                <h4 className="text-xs font-bold uppercase text-slate-400 mb-3 tracking-wider flex items-center">
                  <History size={14} className="mr-1.5" /> Repayment History
                </h4>
                <div className="space-y-2">
                  {loan.repayments.map(rp => {
                    const acc = accounts.find(a => a.id === rp.accountId);
                    return (
                      <div key={rp.id} className="flex items-center justify-between text-sm py-1 border-b border-slate-50 last:border-0">
                        <div className="flex items-center space-x-6">
                          <span className="text-slate-500 font-medium w-24">
                            {new Date(rp.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                          </span>
                          <span className="text-slate-600 truncate max-w-[120px] md:max-w-none">
                            {acc?.account_name}
                          </span>
                          <span className="text-slate-400 italic text-xs">
                            {rp.notes !== 'Direct repayment' && rp.notes ? rp.notes : ''}
                          </span>
                        </div>
                        <span className="text-emerald-600 font-bold">
                          +{rp.amount.toLocaleString()} MK
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        ))}
        {activeLoans.length === 0 && (
          <div className="p-12 text-center text-slate-400 border border-dashed border-slate-200 rounded-xl">
            No loans recorded on or before {new Date(workingDate).toLocaleDateString()}.
          </div>
        )}
      </div>

      {modalType && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[60] p-4">
          <div className="bg-white rounded-xl w-full max-w-md p-6 shadow-xl">
            <h2 className="text-xl font-bold mb-4 text-slate-900">{modalType === 'NEW_LOAN' ? 'Grant New Loan' : 'Record Repayment'}</h2>
            
            {error && (
              <div className="mb-4 p-3 bg-red-50 text-red-700 text-sm rounded-lg flex items-center">
                <AlertCircle size={16} className="mr-2" />
                {error}
              </div>
            )}

            <form onSubmit={handleAction} className="space-y-4">
              {modalType === 'NEW_LOAN' ? (
                <>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Member</label>
                    <select 
                      required 
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-900"
                      value={formData.memberId}
                      onChange={(e) => setFormData({...formData, memberId: e.target.value})}
                      disabled={isSubmitting}
                    >
                      <option value="">Select Member</option>
                      {members.filter(m => m.active).map(m => (
                        <option key={m.id} value={m.id}>{m.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Amount (MK)</label>
                      <input 
                        type="number" required 
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-900"
                        value={formData.amount}
                        onChange={(e) => setFormData({...formData, amount: e.target.value})}
                        disabled={isSubmitting}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Interest (%)</label>
                      <input 
                        type="number" required 
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-900"
                        value={formData.interestRate}
                        onChange={(e) => setFormData({...formData, interestRate: e.target.value})}
                        disabled={isSubmitting}
                      />
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="p-3 bg-blue-50 text-blue-800 text-sm rounded-lg mb-4">
                    Repayment for <strong>{activeLoans.find(l => l.id === selectedLoanId)?.member?.name}</strong>'s loan.
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Repayment Amount (MK)</label>
                    <input 
                      type="number" required 
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-900"
                      value={formData.amount}
                      onChange={(e) => setFormData({...formData, amount: e.target.value})}
                      disabled={isSubmitting}
                    />
                  </div>
                </>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Account</label>
                <select 
                  required 
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-900"
                  value={formData.accountId}
                  onChange={(e) => setFormData({...formData, accountId: e.target.value})}
                  disabled={isSubmitting}
                >
                  <option value="">Select Account</option>
                  {accounts.filter(a => a.active).map(a => (
                    <option key={a.id} value={a.id}>{a.account_name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Date</label>
                <input 
                  type="date" required 
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-900"
                  value={formData.date}
                  onChange={(e) => setFormData({...formData, date: e.target.value})}
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Notes (Optional)</label>
                <textarea 
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-900"
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  disabled={isSubmitting}
                />
              </div>

              <div className="flex space-x-3 pt-4">
                <button type="button" onClick={closeModal} className="flex-1 px-4 py-2 border rounded-lg" disabled={isSubmitting}>Cancel</button>
                <button type="submit" className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex justify-center items-center" disabled={isSubmitting}>
                   {isSubmitting ? <Loader2 className="animate-spin" size={18} /> : 'Confirm'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
