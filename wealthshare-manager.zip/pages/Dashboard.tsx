
import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie
} from 'recharts';
import { 
  Banknote, 
  TrendingUp, 
  Users, 
  AlertCircle,
  CalendarClock,
  ArrowRight,
  PlusCircle
} from 'lucide-react';
import { useStore } from '../store';
import { Link } from 'react-router-dom';

const KPICard: React.FC<{ title: string, value: string, icon: React.ReactNode, color: string }> = ({ title, value, icon, color }) => (
  <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
    <div className="flex items-center justify-between mb-4">
      <div className={`p-3 rounded-lg ${color} bg-opacity-10 text-${color.split('-')[1]}-600`}>
        {icon}
      </div>
    </div>
    <p className="text-sm font-medium text-slate-500 mb-1">{title}</p>
    <h3 className="text-2xl font-bold text-slate-900">{value} MK</h3>
  </div>
);

export const Dashboard: React.FC = () => {
  const { transactions, loans, accounts, getLoanDetails, getAccountBalance, workingDate } = useStore();

  // Filter transactions based on workingDate
  const filteredTransactions = transactions.filter(t => t.date <= workingDate);

  const totalPrincipal = filteredTransactions.filter(t => t.fund_type === 'PRINCIPAL').reduce((sum, t) => sum + t.amount, 0);
  const totalInterest = filteredTransactions.filter(t => t.fund_type === 'INTEREST').reduce((sum, t) => sum + t.amount, 0);
  const totalFunds = totalPrincipal + totalInterest;

  // Filter loans based on workingDate
  const activeLoans = loans
    .filter(l => l.date_given <= workingDate)
    .map(l => ({ ...l, ...getLoanDetails(l) }))
    .filter(l => l.status !== 'PAID');
    
  const outstandingLoansTotal = activeLoans.reduce((sum, l) => sum + l.balance, 0);
  
  const today = new Date(workingDate);
  const threeDaysFromNow = new Date(workingDate);
  threeDaysFromNow.setDate(today.getDate() + 3);

  const dueSoonCount = activeLoans.filter(l => {
    const dueDate = new Date(l.due_date);
    return dueDate > today && dueDate <= threeDaysFromNow;
  }).length;

  const overdueCount = activeLoans.filter(l => l.status === 'OVERDUE').length;

  const accountBalances = accounts.map(acc => ({
    name: acc.account_name,
    ...getAccountBalance(acc.id)
  }));

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Financial Dashboard</h1>
          <p className="text-slate-500">Overview of group savings and loans (As of {new Date(workingDate).toLocaleDateString()})</p>
        </div>
        <Link 
          to="/transactions" 
          className="flex items-center justify-center space-x-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors shadow-sm font-bold animate-in fade-in slide-in-from-right-4"
        >
          <PlusCircle size={20} />
          <span>Record Entry</span>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <KPICard 
          title="Total Principal" 
          value={totalPrincipal.toLocaleString()} 
          icon={<TrendingUp size={24} />} 
          color="bg-blue-500" 
        />
        <KPICard 
          title="Total Interest" 
          value={totalInterest.toLocaleString()} 
          icon={<Banknote size={24} />} 
          color="bg-emerald-500" 
        />
        <KPICard 
          title="Total Funds (Net)" 
          value={totalFunds.toLocaleString()} 
          icon={<Wallet size={24} className="text-amber-500" />} 
          color="bg-amber-500" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-semibold mb-6">Balances by Account</h3>
          <div className="w-full" style={{ height: 300 }}>
             {accountBalances.length > 0 ? (
               <ResponsiveContainer width="100%" height="100%">
                 <BarChart data={accountBalances} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                   <CartesianGrid strokeDasharray="3 3" vertical={false} />
                   <XAxis dataKey="name" />
                   <YAxis />
                   <Tooltip 
                     formatter={(value: number) => `${value.toLocaleString()} MK`}
                     cursor={{ fill: 'transparent' }}
                   />
                   <Bar dataKey="principal" name="Principal" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                   <Bar dataKey="interest" name="Interest" fill="#10b981" radius={[4, 4, 0, 0]} />
                 </BarChart>
               </ResponsiveContainer>
             ) : (
               <div className="flex h-full items-center justify-center text-slate-400 italic">
                 No active accounts found.
               </div>
             )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-full">
            <h3 className="text-sm font-medium text-slate-500 mb-4 flex items-center">
              <AlertCircle size={16} className="mr-2 text-red-500" />
              Loan Alerts
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Outstanding</span>
                <span className="font-bold">{outstandingLoansTotal.toLocaleString()} MK</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Due Soon</span>
                <span className={`px-2 py-0.5 rounded text-xs font-bold ${dueSoonCount > 0 ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-700'}`}>
                  {dueSoonCount}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Overdue</span>
                <span className={`px-2 py-0.5 rounded text-xs font-bold ${overdueCount > 0 ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-700'}`}>
                  {overdueCount}
                </span>
              </div>
            </div>
            <Link to="/loans" className="mt-6 flex items-center justify-center text-sm font-medium text-blue-600 hover:text-blue-700">
              Manage Loans <ArrowRight size={16} className="ml-1" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

// Utility Icons needed for Dashboard
const Wallet: React.FC<any> = ({ ...props }) => (
  <svg
    {...props}
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M21 12V7H5a2 2 0 0 1 0-4h14v4" />
    <path d="M3 5v14a2 2 0 0 0 2 2h16v-5" />
    <path d="M18 12a2 2 0 0 0 0 4h4v-4Z" />
  </svg>
);
