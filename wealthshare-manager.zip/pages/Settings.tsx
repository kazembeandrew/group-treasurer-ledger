
import React, { useRef, useState, useEffect } from 'react';
import { useStore } from '../store';
import { 
  Download, 
  Upload, 
  Trash2, 
  AlertTriangle,
  Save,
  ShieldCheck,
  Cloud,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

export const Settings: React.FC = () => {
  const { exportData, importData, resetData, isCloudMode } = useStore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [supabaseUrl, setSupabaseUrl] = useState('');
  const [supabaseKey, setSupabaseKey] = useState('');

  useEffect(() => {
    // Load existing settings if available
    const storedUrl = localStorage.getItem('wealthshare_supabase_url');
    const storedKey = localStorage.getItem('wealthshare_supabase_key');
    if (storedUrl) setSupabaseUrl(storedUrl);
    if (storedKey) setSupabaseKey(storedKey);
  }, []);

  const handleConnect = () => {
    if (!supabaseUrl.trim() || !supabaseKey.trim()) {
      alert("Please enter both URL and Key.");
      return;
    }
    
    // Validate URL format
    try {
      new URL(supabaseUrl.trim());
    } catch (e) {
      alert("Invalid URL format. Please include https://");
      return;
    }

    localStorage.setItem('wealthshare_supabase_url', supabaseUrl.trim());
    localStorage.setItem('wealthshare_supabase_key', supabaseKey.trim());
    
    // Soft reload to apply changes without risking 404s on some hosts
    window.location.href = window.location.href.split('#')[0];
  };

  const handleDisconnect = () => {
    localStorage.removeItem('wealthshare_supabase_url');
    localStorage.removeItem('wealthshare_supabase_key');
    window.location.reload();
  };

  const handleExport = () => {
    const dataStr = exportData();
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `wealthshare_backup_${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        const success = importData(event.target.result as string);
        if (success && fileInputRef.current) {
          fileInputRef.current.value = ''; // Reset input
        }
      }
    };
    reader.readAsText(file);
  };

  const handleReset = () => {
    if (window.confirm('Are you absolutely sure? This will delete ALL members, transactions, and loans. This action cannot be undone.')) {
      if (window.confirm('Seriously, everything will be gone. Did you make a backup?')) {
        resetData();
      }
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Settings</h1>
        <p className="text-slate-500">Manage your data and system preferences</p>
      </div>

      {/* Cloud Connection Card */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="p-6 border-b border-slate-200">
           <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className={`p-2 rounded-lg ${isCloudMode ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-600'}`}>
                <Cloud size={24} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Cloud Connection</h3>
                <p className="text-sm text-slate-500">Sync data with your Supabase database.</p>
              </div>
            </div>
            {isCloudMode && (
              <span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-xs font-bold flex items-center">
                <CheckCircle size={14} className="mr-1" /> Connected
              </span>
            )}
            {!isCloudMode && (
              <span className="bg-slate-100 text-slate-500 px-3 py-1 rounded-full text-xs font-bold flex items-center">
                <AlertCircle size={14} className="mr-1" /> Offline
              </span>
            )}
           </div>

           <div className="space-y-4">
             <div>
               <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Project URL</label>
               <input 
                 type="text" 
                 className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-slate-50 text-slate-900 text-sm font-mono"
                 placeholder="https://xyz.supabase.co"
                 value={supabaseUrl}
                 onChange={(e) => setSupabaseUrl(e.target.value)}
               />
             </div>
             <div>
               <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Anon Public Key</label>
               <input 
                 type="password" 
                 className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-slate-50 text-slate-900 text-sm font-mono"
                 placeholder="eyJxh..."
                 value={supabaseKey}
                 onChange={(e) => setSupabaseKey(e.target.value)}
               />
             </div>
             
             <div className="flex gap-3">
               <button 
                 onClick={handleConnect}
                 className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 font-medium text-sm"
               >
                 Connect & Reload
               </button>
               {isCloudMode && (
                 <button 
                   onClick={handleDisconnect}
                   className="border border-red-200 text-red-600 px-4 py-2 rounded-lg hover:bg-red-50 font-medium text-sm"
                 >
                   Disconnect
                 </button>
               )}
             </div>
             
             <p className="text-xs text-slate-400">
               Your keys are stored locally in your browser to maintain the connection.
             </p>
           </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="p-6 border-b border-slate-200">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-blue-100 rounded-lg text-blue-600">
              <Save size={24} />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">Data Backup</h3>
              <p className="text-sm text-slate-500">Save your records to your device.</p>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={handleExport}
              className="flex items-center justify-center space-x-2 bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium flex-1"
            >
              <Download size={18} />
              <span>Export Data (JSON)</span>
            </button>
          </div>
        </div>

        <div className="p-6 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center space-x-3 mb-4">
             <div className="p-2 bg-emerald-100 rounded-lg text-emerald-600">
              <Upload size={24} />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">Restore Data</h3>
              <p className="text-sm text-slate-500">Restore from a previously exported backup file.</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <input 
              type="file" 
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="application/json"
              className="hidden"
            />
            <button 
              onClick={handleImportClick}
              className="flex items-center justify-center space-x-2 bg-white border border-slate-300 text-slate-700 px-4 py-3 rounded-lg hover:bg-slate-100 transition-colors font-medium flex-1"
            >
              <Upload size={18} />
              <span>Import Backup File</span>
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="flex items-center space-x-3 mb-4 text-red-600">
             <div className="p-2 bg-red-100 rounded-lg">
              <AlertTriangle size={24} />
            </div>
            <div>
              <h3 className="text-lg font-bold">Danger Zone</h3>
              <p className="text-sm text-red-600/80">Irreversible actions.</p>
            </div>
          </div>

          <button 
            onClick={handleReset}
            className="flex items-center justify-center space-x-2 bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg hover:bg-red-100 transition-colors font-medium w-full sm:w-auto"
          >
            <Trash2 size={18} />
            <span>Delete All Data & Reset</span>
          </button>
        </div>
      </div>

      <div className="flex items-start space-x-3 p-4 bg-blue-50 text-blue-800 rounded-xl text-sm">
        <ShieldCheck className="shrink-0 mt-0.5" size={18} />
        <p>
          <strong>Privacy Note:</strong> When Offline, data is stored in your browser. When Connected, data is synced to your specific Supabase project. We do not track your financial data.
        </p>
      </div>
    </div>
  );
};
