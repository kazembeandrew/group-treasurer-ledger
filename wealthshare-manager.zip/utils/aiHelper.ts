
import { GoogleGenAI } from "@google/genai";
import { Member, Account, Loan, Transaction, AccountType, ActionDraft, ChatMessage } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface AIResponse {
  type: 'ANSWER' | 'DRAFT_ACTIONS';
  text?: string;
  actions?: ActionDraft[];
}

export const askFinancialAssistant = async (
  userPrompt: string, 
  context: { 
    members: Member[], 
    accounts: Account[], 
    loans: Loan[], 
    transactions: Transaction[],
    workingDate: string,
    chatHistory: ChatMessage[]
  }
): Promise<AIResponse> => {
  
  const activeMembers = context.members.map(m => ({ id: m.id, name: m.name }));
  const activeAccounts = context.accounts.map(a => ({ id: a.id, name: a.account_name, type: a.type }));
  
  // We only need a summary of loans for context
  const activeLoans = context.loans
    .filter(l => l.date_given <= context.workingDate)
    .map(l => {
       const m = context.members.find(mem => mem.id === l.memberId);
       return { id: l.id, member: m?.name, amount: l.amount_given, date: l.date_given };
    });

  // Format recent chat history (last 10 messages)
  const recentHistory = context.chatHistory
    .slice(-10)
    .map(msg => `${msg.sender.toUpperCase()}: ${msg.text || (msg.actions ? `[Generated ${msg.actions.length} actions]` : '')}`)
    .join('\n');

  const systemInstruction = `
    You are the ADMIN AI for 'WealthShare'. You have FULL CONTROL to modify the database.
    
    CONTEXT:
    Reference Date (Today): ${context.workingDate}
    Members: ${JSON.stringify(activeMembers)}
    Accounts: ${JSON.stringify(activeAccounts)}
    Existing Loans: ${JSON.stringify(activeLoans)}

    PREVIOUS CHAT HISTORY:
    ${recentHistory}

    CAPABILITIES:
    1. ADD MEMBER: type='ADD_MEMBER' { memberName, startingCredit }
    2. ADD ACCOUNT: type='ADD_ACCOUNT' { accountName, accountType (CASH/MOBILE/BANK/MEMBER), memberId (if type=MEMBER) }
    3. CREATE LOAN: type='CREATE_LOAN' { memberId, amount, accountId, date, interestRate }
    4. RECORD TRANSACTIONS: type='CONTRIBUTION' | 'LOAN_REPAYMENT' | 'EXPENSE' | 'TRANSFER'
    5. ANSWER QUESTIONS.

    RULES:
    - 'Everyone' = all active members.
    - If user lists people, generate actions for all of them.
    - Default Interest Rate = 10% if not specified.
    - Default Account = 'CASH' (Account ID '1') if not specified.
    - Date format: YYYY-MM-DD.
    - You can generate up to 400 actions.
    - For TRANSFER, use 'fromAccountId' as 'accountId' and 'toAccountId'.
    
    OUTPUT FORMAT (JSON ONLY):
    
    { 
      "type": "DRAFT_ACTIONS", 
      "actions": [
        {
          "type": "ADD_MEMBER",
          "memberName": "John Doe",
          "startingCredit": 0
        },
        {
          "type": "CONTRIBUTION",
          "memberId": "UUID",
          "accountId": "UUID",
          "amount": 1000,
          "date": "2024-01-01"
        }
      ]
    }
    OR
    { "type": "ANSWER", "text": "..." }

    If you refuse or cannot perform a request, return type="ANSWER" with the explanation.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userPrompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json"
      }
    });

    const responseText = response.text;
    if (!responseText) {
      // Check for block reason
      if (response.candidates && response.candidates.length > 0 && response.candidates[0].finishReason !== 'STOP') {
         return {
            type: 'ANSWER',
            text: `I cannot complete this request. (Reason: ${response.candidates[0].finishReason})`
         };
      }
      throw new Error("Empty response from AI");
    }

    try {
      const parsed = JSON.parse(responseText.trim());
      // Validate structure
      if (parsed.type === 'ANSWER' || parsed.type === 'DRAFT_ACTIONS') {
        return parsed as AIResponse;
      }
      // Return weird JSON as text
      return { type: 'ANSWER', text: JSON.stringify(parsed) };
    } catch (e) {
      // If parsing fails, the model likely returned plain text refusing the command or explaining something.
      console.warn("AI response was not JSON:", responseText);
      return {
        type: 'ANSWER',
        text: responseText
      };
    }

  } catch (error: any) {
    console.error("AI Error:", error);
    return {
      type: 'ANSWER',
      text: `I'm having trouble processing that request: ${error.message || "Unknown error"}`
    };
  }
};
