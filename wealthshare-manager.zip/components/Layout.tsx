
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  Wallet, 
  ArrowLeftRight, 
  Banknote, 
  Bell, 
  X,
  Menu,
  Calendar,
  FileText,
  Settings,
  Sparkles,
  Cloud,
  CloudOff
} from 'lucide-react';
import { useStore } from '../store';

const NavItem: React.FC<{ to: string, icon: React.ReactNode, label: string, onClick?: () => void }> = ({ to, icon, label, onClick }) => {
  const location = useLocation();
  const isActive = location.pathname === to;
  return (
    <Link 
      to={to} 
      onClick={onClick}
      className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
        isActive ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-blue-50 hover:text-blue-600'
      }`}
    >
      {icon}
      <span className="font-medium">{label}</span>
    </Link>
  );
};

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { notifications, dismissNotification, workingDate, setWorkingDate, isCloudMode } = useStore();

  const isToday = workingDate === new Date().toISOString().split('T')[0];

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-50">
      {/* Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-50 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 w-64 bg-white border-r transform transition-transform duration-200 ease-in-out z-50
        md:relative md:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="p-6">
          <h1 className="text-2xl font-bold text-blue-600 mb-2 hidden md:block">WealthShare</h1>
          
          <div className={`text-xs font-semibold px-2 py-1 rounded inline-flex items-center mb-6 gap-1 ${
            isCloudMode ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'
          }`}>
             {isCloudMode ? <Cloud size={12} /> : <CloudOff size={12} />}
             {isCloudMode ? 'ONLINE' : 'OFFLINE MODE'}
          </div>

          <nav className="space-y-1">
            <NavItem to="/" icon={<LayoutDashboard size={20} />} label="Dashboard" onClick={() => setIsSidebarOpen(false)} />
            
            {/* AI Assistant Highlighted */}
            <NavItem 
              to="/ai" 
              icon={<Sparkles size={20} className="text-purple-500" />} 
              label="AI Assistant" 
              onClick={() => setIsSidebarOpen(false)} 
            />

            <NavItem to="/members" icon={<Users size={20} />} label="Members" onClick={() => setIsSidebarOpen(false)} />
            <NavItem to="/accounts" icon={<Wallet size={20} />} label="Accounts" onClick={() => setIsSidebarOpen(false)} />
            <NavItem to="/transactions" icon={<ArrowLeftRight size={20} />} label="Transactions" onClick={() => setIsSidebarOpen(false)} />
            <NavItem to="/loans" icon={<Banknote size={20} />} label="Loans" onClick={() => setIsSidebarOpen(false)} />
            <NavItem to="/reports" icon={<FileText size={20} />} label="Reports" onClick={() => setIsSidebarOpen(false)} />
            
            <div className="pt-4 mt-4 border-t border-slate-100">
              <NavItem to="/settings" icon={<Settings size={20} />} label="Settings" onClick={() => setIsSidebarOpen(false)} />
            </div>
          </nav>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-h-screen">
        {/* Top Header / Working Date Selector */}
        <header className="bg-white border-b px-4 md:px-8 py-3 flex items-center justify-between sticky top-0 z-40 shadow-sm">
          <div className="flex items-center space-x-4">
            <button onClick={() => setIsSidebarOpen(true)} className="md:hidden p-2 text-slate-600">
              <Menu size={24} />
            </button>
            <h1 className="text-xl font-bold text-blue-600 md:hidden">WealthShare</h1>
            
            {/* Working Date Selector */}
            <div className={`hidden sm:flex items-center space-x-2 px-3 py-1.5 rounded-lg border transition-colors ${!isToday ? 'bg-amber-50 border-amber-200 text-amber-700' : 'bg-slate-50 border-slate-200 text-slate-600'}`}>
              <Calendar size={16} />
              <label htmlFor="workingDate" className="text-xs font-bold uppercase tracking-wider">Entry Date:</label>
              <input 
                type="date" 
                id="workingDate"
                className="bg-transparent border-none focus:ring-0 text-sm font-semibold outline-none cursor-pointer"
                value={workingDate}
                onChange={(e) => setWorkingDate(e.target.value)}
              />
              {!isToday && (
                <button 
                  onClick={() => setWorkingDate(new Date().toISOString().split('T')[0])}
                  className="text-[10px] font-bold bg-amber-200 px-1.5 py-0.5 rounded hover:bg-amber-300"
                >
                  RESET TO TODAY
                </button>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-3">
             {/* Mobile Entry Date Button (Compact) */}
             <div className={`sm:hidden flex items-center px-2 py-1 rounded border ${!isToday ? 'bg-amber-50 border-amber-200 text-amber-700' : 'bg-slate-50 border-slate-200 text-slate-600'}`}>
               <input 
                type="date" 
                className="bg-transparent border-none focus:ring-0 text-xs font-semibold outline-none"
                value={workingDate}
                onChange={(e) => setWorkingDate(e.target.value)}
              />
             </div>
          </div>
        </header>

        {/* Notifications Bar */}
        {notifications.length > 0 && (
          <div className="max-h-48 overflow-y-auto p-4 space-y-2 bg-slate-100/50 backdrop-blur-sm border-b z-30">
            {notifications.map(notif => (
              <div key={notif.id} className={`
                p-3 rounded-lg border flex items-start justify-between animate-in fade-in slide-in-from-top-2
                ${notif.type === 'error' ? 'bg-red-50 border-red-200 text-red-800' : 
                  notif.type === 'warning' ? 'bg-amber-50 border-amber-200 text-amber-800' : 
                  'bg-blue-50 border-blue-200 text-blue-800'}
              `}>
                <div className="flex space-x-3">
                  <Bell size={18} className="mt-0.5 shrink-0" />
                  <p className="text-sm">{notif.message}</p>
                </div>
                <button onClick={() => dismissNotification(notif.id)} className="p-1 hover:bg-black/5 rounded">
                  <X size={16} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Page Content */}
        <main className="p-4 md:p-8 overflow-y-auto flex-1">
          {children}
        </main>
      </div>
    </div>
  );
};
